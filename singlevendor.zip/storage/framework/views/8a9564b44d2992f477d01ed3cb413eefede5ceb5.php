<div class="sidebar-body">
    <ul class="nav">
        <li class="nav-item nav-category"><?php echo e(__('Main')); ?></li>
        <li class="nav-item <?php if(request()->is('admin/dashboard')): ?> <?php echo e('active'); ?> <?php endif; ?>">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link">
                <i class="link-icon" data-feather="box"></i>
                <span class="link-title"><?php echo e(__('Dashboard')); ?></span>
            </a>
        </li>
        <li class="nav-item nav-category"><?php echo e(__('User Part')); ?></li>
        <li class="nav-item <?php if(request()->is('admin/admins') || request()->is('admin/admins/*')): ?> <?php echo e('active'); ?> <?php endif; ?>">
            <a class="nav-link" data-toggle="collapse" href="#adminnav" role="button" aria-expanded="false"
                aria-controls="adminnav">
                <i class="link-icon" data-feather="user-check"></i>
                <span class="link-title"><?php echo e(__('Admin')); ?></span>
                <i class="link-arrow" data-feather="chevron-down"></i>
            </a>
            <div class="collapse <?php if(request()->is('admin/admins') || request()->is('admin/admins/*')): ?> <?php echo e('show'); ?> <?php endif; ?>" id="adminnav" >
                <ul class="nav sub-menu">
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.admins.create')); ?>"
                            class="nav-link <?php if(request()->is('admin/admins/create')): ?> <?php echo e('active'); ?> <?php endif; ?>"><?php echo e(__('New Admin')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.admins.index')); ?>"
                            class="nav-link <?php if(request()->is('admin/admins')): ?> <?php echo e('active'); ?> <?php endif; ?>"><?php echo e(__('All Admin')); ?></a>
                    </li>
                </ul>
            </div>
        </li>
        <li class="nav-item <?php if(request()->is('admin/users') || request()->is('admin/users/*')): ?> <?php echo e('active'); ?> <?php endif; ?>">
            <a class="nav-link" data-toggle="collapse" href="#userControl" role="button" aria-expanded="false"
                aria-controls="userControl">
                <i class="link-icon" data-feather="user-plus"></i>
                <span class="link-title"><?php echo e(__('User')); ?></span>
                <i class="link-arrow" data-feather="chevron-down"></i>
            </a>
            <div class="collapse <?php if(request()->is('admin/users') || request()->is('admin/users/*')): ?> <?php echo e('show'); ?> <?php endif; ?>" id="userControl">
                <ul class="nav sub-menu">
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.users.create')); ?>"
                            class="nav-link <?php if(request()->is('admin/users/create')): ?> <?php echo e('active'); ?> <?php endif; ?>"><?php echo e(__('New User')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.users.index')); ?>"
                            class="nav-link <?php if(request()->is('admin/users')): ?> <?php echo e('active'); ?> <?php endif; ?>"><?php echo e(__('All User')); ?></a>
                    </li>
                </ul>
            </div>
        </li>
        <li class="nav-item nav-category"><?php echo e(__('Product Part')); ?></li>
        <li class="nav-item <?php if(request()->is('admin/products') || request()->is('admin/products/*')): ?> <?php echo e('active'); ?> <?php endif; ?>">
            <a class="nav-link" data-toggle="collapse" href="#productControl" role="button" aria-expanded="false"
                aria-controls="productControl">
                <i class="link-icon" data-feather="file-text"></i>
                <span class="link-title"><?php echo e(__('Products')); ?></span>
                <i class="link-arrow" data-feather="chevron-down"></i>
            </a>
            <div class="collapse <?php if(request()->is('admin/products') || request()->is('admin/products/*')): ?> <?php echo e('show'); ?> <?php endif; ?>" id="productControl">
                <ul class="nav sub-menu">
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.products.create')); ?>"
                            class="nav-link <?php if(request()->is('admin/products/create')): ?> <?php echo e('active'); ?> <?php endif; ?>"><?php echo e(__('New Product')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.products.index')); ?>"
                            class="nav-link <?php if(request()->is('admin/products')): ?> <?php echo e('active'); ?> <?php endif; ?>"><?php echo e(__('All Products')); ?></a>
                    </li>
                </ul>
            </div>
        </li>
        <li class="nav-item <?php if(request()->is('admin/brands')): ?> <?php echo e('active'); ?> <?php endif; ?>">
            <a href="<?php echo e(route('admin.brands.index')); ?>" class="nav-link">
                <i class="link-icon" data-feather="codepen"></i>
                <span class="link-title"><?php echo e(__('Brand')); ?></span>
            </a>
        </li>
        <li class="nav-item <?php if(request()->is('admin/categories')): ?> <?php echo e('active'); ?> <?php endif; ?>">
            <a href="<?php echo e(route('admin.categories.index')); ?>" class="nav-link">
                <i class="link-icon" data-feather="disc"></i>
                <span class="link-title"><?php echo e(__('Categories')); ?></span>
            </a>
        </li>
        <li class="nav-item <?php if(request()->is('admin/product-stock')): ?> <?php echo e('active'); ?> <?php endif; ?>">
            <a href="<?php echo e(route('admin.product.stock')); ?>" class="nav-link">
                <i class="link-icon" data-feather="layers"></i>
                <span class="link-title"><?php echo e(__('Stock')); ?></span>
            </a>
        </li>
        
        <li class="nav-item nav-category"><?php echo e(__('Service Part')); ?></li>
        <li class="nav-item <?php if(request()->is('admin/orders')): ?> <?php echo e('active'); ?> <?php endif; ?>">
            <a href="<?php echo e(route('admin.orders.index')); ?>" class="nav-link">
                <i class="link-icon" data-feather="codepen"></i>
                <?php if( neworder() >0 ): ?>
                <span class="notification"><?php echo e(neworder()); ?></span>
                <?php endif; ?>
                <span class="link-title"><?php echo e(__('Orders')); ?></span>
            </a>
        </li>
        <li class="nav-item <?php if(request()->is('admin/product-request')): ?> <?php echo e('active'); ?> <?php endif; ?>">
            <a href="<?php echo e(route('admin.requestproduct.index')); ?>" class="nav-link">
                <i class="link-icon" data-feather="codepen"></i>
                <?php if( newrequest() > 0 ): ?>
                <span class="notification"><?php echo e(newrequest()); ?></span>
                <?php endif; ?>

                <span class="link-title"><?php echo e(__('Requested')); ?> </span>
            </a>
        </li>
        <li class="nav-item <?php if(request()->is('admin/sale-report')): ?> <?php echo e('active'); ?> <?php endif; ?>">
            <a href="<?php echo e(route('admin.report.salesearch')); ?>" class="nav-link">
                <i class="link-icon" data-feather="file"></i>

                <span class="link-title"><?php echo e(__('Sale Report')); ?> </span>
            </a>
        </li>

        <li class="nav-item nav-category"><?php echo e(__('Marketing Part')); ?></li>
        <li class="nav-item <?php if(request()->is('admin/coupons')): ?> <?php echo e('active'); ?> <?php endif; ?>">
            <a href="<?php echo e(route('admin.coupons.index')); ?>" class="nav-link">
                <i class="link-icon" data-feather="aperture"></i>
                <span class="link-title"><?php echo e(__('Coupons')); ?></span>
            </a>
        </li>
        <li class="nav-item nav-category"><?php echo e(__('General Part')); ?></li>

        <li class="nav-item <?php if(request()->is('admin/generals')): ?> <?php echo e('active'); ?> <?php endif; ?>">
            <a href="<?php echo e(route('admin.generals.index')); ?>" class="nav-link">
                <i class="link-icon" data-feather="info"></i>
                <span class="link-title"><?php echo e(__('General')); ?></span>
            </a>
        </li>
        <li class="nav-item <?php if(request()->is('admin/faqs')): ?> <?php echo e('active'); ?> <?php endif; ?>">
            <a href="<?php echo e(route('admin.faqs.index')); ?>" class="nav-link">
                <i class="link-icon" data-feather="help-circle"></i>
                <span class="link-title"><?php echo e(__('FAQ')); ?></span>
            </a>
        </li>
        <li class="nav-item <?php if(request()->is('admin/sliders')): ?> <?php echo e('active'); ?> <?php endif; ?>">
            <a href="<?php echo e(route('admin.sliders.index')); ?>" class="nav-link">
                <i class="link-icon" data-feather="image"></i>
                <span class="link-title"><?php echo e(__('Slider')); ?></span>
            </a>
        </li>

        <li class="nav-item <?php if(request()->is('admin/pages') || request()->is('admin/pages/*')): ?> <?php echo e('active'); ?> <?php endif; ?>">
            <a class="nav-link" data-toggle="collapse" href="#pageControl" role="button" aria-expanded="false"
                aria-controls="pageControl">
                <i class="link-icon" data-feather="file-text"></i>
                <span class="link-title"><?php echo e(__('Pages')); ?></span>
                <i class="link-arrow" data-feather="chevron-down"></i>
            </a>
            <div class="collapse" id="pageControl">
                <ul class="nav sub-menu">
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.pages.create')); ?>"
                            class="nav-link"><?php echo e(__('New Page')); ?></a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.pages.index')); ?>"
                            class="nav-link <?php echo e(Request::is('admin/pages') ? 'active' : ''); ?>"><?php echo e(__('All Page')); ?></a>
                    </li>
                </ul>
            </div>
        </li>
    </ul>
</div>
<?php /**PATH E:\wamp64\www\amrlogde\singlevendor\resources\views/backend/layouts/sidebar.blade.php ENDPATH**/ ?>