<?php $__env->startSection('title', 'New Admin'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="row">
            <div class="col-md-12 grid-margin">
                <div class="card">
                    <div class="card-body">
                        <?php echo $__env->make('includes.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                       <div class="d-flex justify-content-between">
                        <h6 class="card-title"><?php echo e(__('New Admin')); ?></h6>
                        <a class="btn btn-outline-primary float-end" href="<?php echo e(route('admin.admins.index')); ?>"
                            ><?php echo e(__('All Admin')); ?></a>
                       </div>

                        <form class="forms-sample" method="POST" action="<?php echo e(route('admin.admins.store')); ?>"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-9">
                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label class="form-label"><?php echo e(__('Name')); ?></label>
                                            <input type="text" class="form-control" placeholder="<?php echo e(__('Name')); ?>"
                                                autocomplete="off" name="name" value="<?php echo e(old('name')); ?>" required="" />
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label"><?php echo e(__('E-mail Address')); ?></label>
                                            <input type="email" class="form-control"
                                                placeholder="<?php echo e(__('E-mail Address')); ?>" autocomplete="off" name="email"
                                                value="<?php echo e(old('email')); ?>" required="" />
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label"><?php echo e(__('Phone')); ?></label>
                                            <input type="text" class="form-control" placeholder="<?php echo e(__('Phone')); ?>"
                                                autocomplete="off" name="phone" value="<?php echo e(old('phone')); ?>" required="" />
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label class="form-label"><?php echo e(__('Password')); ?></label>
                                            <input type="password" class="form-control"
                                                placeholder="<?php echo e(__('Password')); ?>" autocomplete="off" name="password"
                                                required="" />
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label"><?php echo e(__('Confirm Password')); ?></label>
                                            <input type="password" class="form-control"
                                                placeholder="<?php echo e(__('Confirm Password')); ?>" autocomplete="off"
                                                name="password_confirmation" required="" />
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-12">
                                            <label class="form-label"><?php echo e(__('Address')); ?></label>
                                            <textarea class="form-control" placeholder="<?php echo e(__('Address')); ?>"
                                                autocomplete="off" name="address"
                                                rows="5" /><?php echo e(old('address')); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-12">
                                            <label class="form-label"><?php echo e(__('Permission')); ?></label>
                                            <select class="js-example-basic-multiple form-select" multiple="multiple"
                                                data-width="100%" name="permission_id[]">
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="card" style="margin-top: 28px">
                                        <div class="card-body">
                                            <center>
                                                <img src="//placehold.it/100x100" id="user-photo">
                                                <p class="card-text mb-3" style="color: red">
                                                    <?php echo e(__('Photo Max Size 100px')); ?></p>
                                                <input type="file" name="photo" onchange="readPicture(this)">
                                            </center>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-12">
                                    <center>
                                        <button type="reset" class="btn btn-outline-danger"><?php echo e(__('Reset')); ?></button>
                                        <button type="submit" class="btn btn-outline-primary"><?php echo e(__('Save')); ?></button>
                                    </center>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        function readPicture(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#user-photo')
                        .attr('src', e.target.result)
                        .width(100)
                        .height(100);
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\amrlogde\singlevendor\resources\views/backend/admin/admins/create.blade.php ENDPATH**/ ?>