<?php $__env->startSection('title', 'Edit Product'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="row">
            <div class="col-md-12 grid-margin">
                <div class="card">
                    <div class="card-body">
                        <?php echo $__env->make('includes.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                       <div class="d-flex justify-content-between">
                        <h6 class="card-title"><?php echo e(__('Edit Product')); ?></h6>
                        <a class="btn btn-outline-primary text-end" href="<?php echo e(route('admin.products.index')); ?>"
                            ><?php echo e(__('All Product')); ?></a>
                       </div>

                        <form class="forms-sample" method="POST" action="<?php echo e(route('admin.products.update', $products->id)); ?>"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <div class="col-md-9">
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label class="form-label"><?php echo e(__('Name')); ?></label>
                                            <input type="text" class="form-control" placeholder="<?php echo e(__('Name')); ?>"
                                                autocomplete="off" name="name" value="<?php echo e(old('name', $products->name)); ?>"
                                                required="" id="name" />
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label"><?php echo e(__('Slug')); ?></label>
                                            <input type="text" class="form-control" placeholder="<?php echo e(__('Slug')); ?>"
                                                autocomplete="off" name="slug" value="<?php echo e(old('slug', $products->slug)); ?>"
                                                required="" id="slug" />
                                        </div>
                                    </div>
                                    
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label class="form-label"><?php echo e(__('Category')); ?></label>
                                            <select name="category_id"  id="category_id"
                                            required="" class="js-example-basic-single form-select" data-width="100%">
                                                <?php $__currentLoopData = $indentedCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryId => $categoryName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($categoryId); ?>" <?php echo e($categoryId==$products->category_id ? 'selected':''); ?>><?php echo e(html_entity_decode($categoryName)); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label"><?php echo e(__('Brand')); ?></label>
                                            <select class="js-example-basic-single form-select" data-width="100%"
                                                name="brand_id" id="brand_id">
                                                <option value=""><?php echo e(__('Select Brand')); ?></option>
                                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"
                                                        <?php if($item->id == $products->brand_id): ?> selected <?php endif; ?>>
                                                        <?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label class="form-label"><?php echo e(__('Sell Price')); ?></label>
                                            <input type="text" class="form-control"
                                                placeholder="<?php echo e(__('Sell Price')); ?>" autocomplete="off" name="price"
                                                value="<?php echo e(old('price', $products->price)); ?>" required=""
                                                id="price" />
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label" for="old_price"><?php echo e(__('Purchase Price')); ?></label>
                                            <input type="text" class="form-control"
                                                placeholder="<?php echo e(__('Purchase Price')); ?>" autocomplete="off" name="old_price"
                                                value="<?php echo e(old('old_price', $products->old_price)); ?>" id="old_price" required />
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label" for="stock"><?php echo e(__('Quantity')); ?></label>
                                            <input type="text" class="form-control"
                                                placeholder="<?php echo e(__('Quantity')); ?>" autocomplete="off" name="stock"
                                                value="<?php echo e(old('discount', $products->stock)); ?>" required id="stock" />
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label class="form-label"
                                                for="discount_type"><?php echo e(__('Discount Type')); ?></label>
                                                <select name="discount_type" id="discount_type" class="form-control">
                                                    <option value="0" <?php if($products->discount_type==0): ?> selected <?php endif; ?>>Discount Type</option>
                                                    <option value="2" <?php if($products->discount_type==2): ?> selected <?php endif; ?>>Percent</option>
                                                    <option value="1" <?php if($products->discount_type==1): ?> selected <?php endif; ?>>Regular</option>
                                                </select>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label" for="discount"><?php echo e(__('Discount')); ?></label>
                                            <input type="text" class="form-control"
                                                placeholder="<?php echo e(__('Discount')); ?>" autocomplete="off" name="discount"
                                                value="<?php echo e(old('discount', $products->discount)); ?>" id="discount" />
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label"><?php echo e(__('Status')); ?></label>
                                            <select class=" form-select" data-width="100%"
                                                name="status" id="status">
                                                <option value=""><?php echo e(__('Status')); ?></option>
                                                <?php $__currentLoopData = getStatus(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($status['value']); ?>" <?php echo e($products->status == $status['value'] ? 'selected':''); ?>><?php echo e($status['label']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row mb-3">

                                        <div class="col-md-12">
                                            <label class="form-label"><?php echo e(__('Tags')); ?></label>
                                            <textarea class="form-control" placeholder="<?php echo e(__('Tags')); ?>" autocomplete="off" name="tags"
                                                rows="3" /><?php echo e(old('tags', $products->tags)); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-12">
                                            <label class="form-label"><?php echo e(__('Description')); ?></label>
                                            <textarea id="editor" name="description" /><?php echo e(old('description', $products->description)); ?></textarea>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-3">
                                    <div class="card" style="margin-top: 28px">
                                        <div class="card-header"><?php echo e(__('Extra')); ?></div>
                                        <div class="card-body">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" value="1" name="featured" <?php echo e($products->featured ==1 ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="flexCheckDefault">
                                                  Featured
                                                </label>
                                              </div>
                                              <div class="form-check">
                                                <input class="form-check-input" type="checkbox" value="1" name="p_set" <?php echo e($products->p_set ==1 ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="flexCheckChecked">
                                                  Perfume Set
                                                </label>
                                              </div>
                                              <div class="form-check">
                                                <input class="form-check-input" type="checkbox" value="1" name="new" <?php echo e($products->new ==1 ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="flexCheckChecked">
                                                  New Arrival
                                                </label>
                                              </div>
                                        </div>
                                    </div>
                                    <div class="card" style="margin-top: 28px">
                                        <div class="card-header"><?php echo e(__('Display Photo')); ?></div>
                                        <div class="card-body">
                                            <center>
                                                <img src="<?php echo e(asset($products->display)); ?>" id="product-photo" width="100px">
                                                <p class="card-text mb-3" style="color: red">
                                                    <?php echo e(__('Photo Max Size 100px')); ?></p>
                                                <input type="file" name="display" onchange="readPicture(this)">
                                            </center>
                                        </div>
                                    </div>
                                    <div class="card" style="margin-top: 28px">
                                        <div class="card-header"><?php echo e(__('More Photo')); ?></div>
                                        <div class="card-body">
                                            <center>
                                                <img src="//placehold.it/100x100">
                                                <p class="card-text mb-3" style="color: red">
                                                    <?php echo e(__('Photo Max Size 100px')); ?></p>
                                                <input type="file" name="photo[]" multiple="">
                                            </center>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-12">
                                    <center>
                                        <button type="reset"
                                            class="btn btn-outline-danger"><?php echo e(__('Reset')); ?></button>
                                        <button type="submit"
                                            class="btn btn-outline-primary"><?php echo e(__('Update')); ?></button>
                                    </center>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        function readPicture(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#product-photo')
                        .attr('src', e.target.result)
                        .width(100)
                        .height(100);
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        $(function() {
            CKEDITOR.replace('editor')
        });

        $("#name").keyup(function() {
            var name = $("#name").val();
            var slug = (name.replace(/[^a-zA-Z0-9]+/g, '-')).toLowerCase();
            $("#slug").val(slug);
        });

        function getSubCategory(category_id) {

            var category = $('#category_id option:selected').text();

            $.ajaxSetup({

                headers: {
                    'X-CSRF-Token': '<?php echo e(csrf_token()); ?>'
                }

            });

            $.ajax({

                url: "<?php echo e(route('admin.get.subcategories')); ?>",
                method: 'POST',
                data: {
                    'category_id': category_id,
                },

                success: function(data2) {

                    var data = JSON.parse(data2);

                    $('#subcategory_id').find('option').remove().end().append("<option value=''>Select " +
                        category + "\'s Sub Category</option>");
                    $('#child_category_id').find('option').remove().end().append("<option value=''>Select " +
                        category + "\'s Child Category</option>");
                    $.each(data, function(i, item) {

                        $("#subcategory_id").append($('<option>', {
                            value: this.id,
                            text: this.name,
                        }));
                    });
                },

                error: function(error) {
                    console.log(error);
                }
            });
        }

        function getChildCategory(subcategory_id) {

            var category = $('#subcategory_id option:selected').text();

            $.ajaxSetup({

                headers: {
                    'X-CSRF-Token': '<?php echo e(csrf_token()); ?>'
                }

            });

            $.ajax({

                url: "<?php echo e(route('admin.get.childcategories')); ?>",
                method: 'POST',
                data: {
                    'sub_category_id': subcategory_id,
                },

                success: function(data2) {

                    var data = JSON.parse(data2);

                    $('#child_category_id').find('option').remove().end().append("<option value=''>Select " +
                        category + "\'s Child Category</option>");

                    $.each(data, function(i, item) {

                        $("#child_category_id").append($('<option>', {
                            value: this.id,
                            text: this.name,
                        }));
                    });
                },

                error: function(error) {
                    console.log(error);
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\amrlogde\singlevendor\resources\views/backend/admin/products/edit.blade.php ENDPATH**/ ?>