<?php $__env->startSection('title', 'All Coupons'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <?php echo $__env->make('includes.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="d-flex justify-content-between">
                            <h6 class="card-title"><?php echo e(__('All Coupons')); ?></h6>
                            <a class="btn btn-outline-primary text-end" data-toggle="modal" data-target="#create"
                                href=""><?php echo e(__('New Coupon')); ?></a>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-stripe">
                                <thead>
                                    <th>SL.</th>
                                    <th>Title</th>
                                    <th>Code</th>
                                    <th>Amount</th>
                                    <th>Expire Date</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e(serialNumber($coupons, $loop)); ?></td>
                                            <td><?php echo e($item->title); ?></td>
                                            <td><?php echo e($item->code); ?></td>
                                            <td><?php echo e($item->amount); ?> <?php echo e($item->amount_type == 1 ? 'TK' : '%'); ?></td>
                                            <td><?php echo e(date('d M, Y', strtotime($item->expires_at))); ?></td>
                                            <td><?php echo e($item->status == 1 ? 'Active' : 'Inactive'); ?></td>
                                            <td>
                                                <a class="btn btn-sm btn-outline-primary editcoupon" data-toggle="modal"
                                                    data-target="#edit" data-id="<?php echo e($item->id); ?>"><i
                                                        data-feather="edit"></i></a>

                                                <a href="" class="btn btn-sm btn-outline-danger"
                                                    data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"
                                                    onclick="if(confirm('Are You Sure To Delete?')){ event.preventDefault(); getElementById('delete-form-<?php echo e($item->id); ?>').submit(); } else { event.preventDefault(); }"><i
                                                        data-feather="x-square"></i></a>
                                                <form action="<?php echo e(route('admin.coupons.destroy', [$item->id])); ?>"
                                                    method="post" style="display: none;"
                                                    id="delete-form-<?php echo e($item->id); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo e(method_field('DELETE')); ?>

                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="5">No Coupon Founds</td>
                                        </tr>
                                    <?php endif; ?>

                                </tbody>
                            </table>
                            <div class="d-flex justify-content-center">
                                <?php echo e($coupons->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade bd-example-modal-xl" tabindex="-1" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true"
        id="create">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title h4" id="myExtraLargeModalLabel"><?php echo e(__('New Coupon')); ?>

                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form class="forms-sample" method="POST" action="<?php echo e(route('admin.coupons.store')); ?>"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row col-md-12 mb-3">
                            <div class="form-group col-md-3">
                                <label class="form-label"><?php echo e(__('Title')); ?></label>
                                <input type="text" class="form-control" placeholder="<?php echo e(__('Title')); ?>"
                                    autocomplete="off" name="title" value="<?php echo e(old('title')); ?>" required=""
                                    id="title" />
                            </div>
                            <div class="form-group col-md-3">
                                <label class="form-label"><?php echo e(__('Code')); ?></label>
                                <input type="text" class="form-control" placeholder="<?php echo e(__('Code')); ?>"
                                    autocomplete="off" name="code" value="<?php echo e(old('code')); ?>" required=""
                                    id="code" />
                            </div>
                            <div class="form-group col-md-3">
                                <label class="form-label"><?php echo e(__('Discount Type')); ?></label>
                                <select class="form-select" data-width="100%" name="amount_type">
                                    <option value=""> Select Type</option>
                                    <option value="1"><?php echo e(__('Reguler')); ?></option>
                                    <option value="2"><?php echo e(__('Percent')); ?></option>

                                </select>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="form-label"><?php echo e(__('Amount')); ?></label>
                                <input type="number" class="form-control" placeholder="<?php echo e(__('Amount')); ?>"
                                    autocomplete="off" name="amount" value="<?php echo e(old('amount')); ?>" required=""
                                    id="amount" />
                            </div>
                            <div class="form-group col-md-3">
                                <label class="form-label"><?php echo e(__('Expires Date')); ?></label>
                                <input type="date" class="form-control" placeholder="<?php echo e(__('Expires Date')); ?>"
                                    autocomplete="off" name="expires_at" value="<?php echo e(old('expires_at')); ?>" required=""
                                    id="expires_at" />
                            </div>
                            <div class="form-group col-md-3">
                                <label class="form-label"><?php echo e(__('Type')); ?></label>
                                <select class="form-select" data-width="100%" name="type">
                                    <option value=""> Select Type</option>
                                    <option value="1">Flat</option>
                                    <option value="2">Category</option>
                                    <option value="3">Brand</option>
                                    <option value="4">Products</option>

                                </select>
                            </div>
                            <div class="form-group col-md-3">
                                <label class="form-label"><?php echo e(__('Limit')); ?></label>
                                <input type="number" class="form-control" placeholder="<?php echo e(__('Limit')); ?>"
                                    autocomplete="off" name="limit" value="<?php echo e(old('limit')); ?>" required=""
                                    id="limit" />
                            </div>
                            <div class="form-group col-md-3">
                                <label class="form-label"><?php echo e(__('Status')); ?></label>
                                <select class="form-select" data-width="100%" name="status" id="status">
                                    <option value=""><?php echo e(__('Status')); ?></option>
                                    <?php $__currentLoopData = getStatus(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($status['value']); ?>"><?php echo e($status['label']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-12">
                                <center>
                                    <button type="reset" class="btn btn-outline-danger"><?php echo e(__('Reset')); ?></button>
                                    <button type="submit" class="btn btn-outline-primary"><?php echo e(__('Save')); ?></button>
                                </center>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade bd-example-modal-xl" tabindex="-1" aria-labelledby="myExtraLargeModalLabel"
        aria-hidden="true" id="edit">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title h4" id="myExtraLargeModalLabel"><?php echo e(__('Edit Coupon')); ?>

                    </h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="editdata">

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            $(".editcoupon").click(function() {
                let coupon = $(this).data('id');
                $.ajax({
                    type: 'get',
                    url: "<?php echo e(route('admin.coupons.edit', ':id')); ?>".replace(':id', coupon),
                    success: function(resp) {
                        $("#editdata").html(resp);
                    },
                    error: function(error) {}
                })

            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\amrlogde\singlevendor\resources\views/backend/admin/coupons/index.blade.php ENDPATH**/ ?>