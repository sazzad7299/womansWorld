<!-- Offcanvas Cart item  Start-->
<div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasCart" aria-labelledby="offcanvasCartLabel">
    <div class="offcanvas-header">

        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        <h5 class="offcanvas-title" id="offcanvasCartLabel">Cart</h5>
    </div>
    <div class="offcanvas-body">
        <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="cart-item">
            <div class="cart-item__image"><img
                    src="<?php echo e(asset($item->options->image)); ?>" alt="Product image">
            </div>
            
            <div class="cart-item__info"><a href="/product-detail.html"><?php echo e($item->name); ?></a>
                <h5><span class="currency_symbol">৳</span><?php echo e($item->price); ?></h5>
                <p>Quantity:<span> <?php echo e($item->qty); ?></span></p>
            </div><a href="<?php echo e(route('cart.remove', ['rowId' => $item->rowId])); ?>" class="cart-item__remove" href="#"><i class="ti ti-close"></i></a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="cart-items__total__price">
            <h5>Total</h5><span><?php echo e(Cart::total()); ?></span>
        </div>
        <div class="mt-3 d-flex justify-content-around">
            <a href="<?php echo e(route('cart')); ?>" class="tm-button">View Cart</a>
            <a href="<?php echo e(route('checkout')); ?>" class="tm-btn-reverse">Checkout</a>
        </div>
    </div>
</div>
<!-- Offcanvas Cart item  End-->
<?php /**PATH E:\wamp64\www\amrlogde\singlevendor\resources\views/components/cart.blade.php ENDPATH**/ ?>