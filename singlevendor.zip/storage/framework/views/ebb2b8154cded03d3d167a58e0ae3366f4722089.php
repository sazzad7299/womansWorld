<?php $__env->startSection('title', 'All Page'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content">

        <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <h6 class="card-title"><?php echo e(__('All Page')); ?></h6>
                        <a class="btn btn-outline-primary float-end" href="<?php echo e(route('admin.pages.create')); ?>"><?php echo e(__('New Page')); ?></a>
                        </div>
                        <hr>
                        <div class="table-responsive">
                            <table id="dataTableExample" class="table">
                                <thead>
                                    <tr>
                                        <th width="5%"><?php echo e(__('Sl')); ?></th>
                                        <th width="15%"><?php echo e(__('Name')); ?></th>
                                        <th width="15%"><?php echo e(__('Slug')); ?></th>
                                        <th width="45%"><?php echo e(__('Content')); ?></th>
                                        <th width="10%"><?php echo e(__('Photo')); ?></th>
                                        <th width="10%"><?php echo e(__('Action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->index + 1); ?></td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->slug); ?></td>
                                            <td><?php echo Str::limit($item->content, 100); ?></td>
                                            <td class="py-1">
                                                <img src="<?php echo e(asset($item->photo)); ?>" alt="image">
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('admin.pages.edit', [$item->id])); ?>"
                                                    class="btn btn-sm btn-outline-primary" data-bs-toggle="tooltip"
                                                    data-bs-placement="top" title="Edit"><i data-feather="edit"></i></a>

                                                <a href="" class="btn btn-sm btn-outline-danger" data-bs-toggle="tooltip"
                                                    data-bs-placement="top" title="Delete"
                                                    onclick="if(confirm('Are You Sure To Delete?')){ event.preventDefault(); getElementById('delete-form-<?php echo e($item->id); ?>').submit(); } else { event.preventDefault(); }"><i
                                                        data-feather="x-square"></i></a>
                                                <form action="<?php echo e(route('admin.pages.destroy', [$item->id])); ?>"
                                                    method="post" style="display: none;"
                                                    id="delete-form-<?php echo e($item->id); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo e(method_field('DELETE')); ?>

                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\amrlogde\singlevendor\resources\views/backend/admin/pages/index.blade.php ENDPATH**/ ?>