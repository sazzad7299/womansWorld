<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title><?php echo $__env->yieldContent('title'); ?></title>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

	<link rel="stylesheet" href="<?php echo e(asset('public/backend/assets/plugins/core/core.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('public/backend/assets/fonts/feather-font/css/iconfont.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('public/backend/assets/plugins/flag-icon-css/css/flag-icon.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('public/backend/assets/css/demo_1/style.css')); ?>">
  <link rel="shortcut icon" href="<?php echo e(asset('public/backend/assets/images/fav.ico')); ?>" />
</head>
<body>
    <?php $__env->startSection('content'); ?>

    <?php echo $__env->yieldSection(); ?>
    <script src="<?php echo e(asset('public/backend/assets/plugins/core/core.js')); ?>"></script>
	<script src="<?php echo e(asset('public/backend/assets/plugins/feather-icons/feather.min.js')); ?>"></script>
	<script src="<?php echo e(asset('public/backend/assets/js/template.js')); ?>"></script>

</body>

</html>
<?php /**PATH E:\wamp64\www\amrlogde\singlevendor\resources\views/auth/app.blade.php ENDPATH**/ ?>