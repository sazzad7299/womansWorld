<?php $__env->startSection('title', 'Brand'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="row">
            <div class="col-md-12 grid-margin">
                <div class="card">
                    <div class="card-body">
                        <?php echo $__env->make('includes.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="d-flex justify-content-between">
                            <h6 class="card-title"><?php echo e(__('Brand')); ?></h6>
                            <a class="btn btn-outline-primary text-end" data-toggle="modal" data-target="#create"
                                href=""><?php echo e(__('New Brand')); ?></a>
                        </div>
                        <div class="table-responsive">
                            <table id="dataTableExample" class="table">
                                <thead>
                                    <tr>
                                        <th width="10%"><?php echo e(__('Sl')); ?></th>
                                        <th width="25%"><?php echo e(__('Name')); ?></th>
                                        <th width="25%"><?php echo e(__('Slug')); ?></th>
                                        <th width="20%"><?php echo e(__('Logo')); ?></th>
                                        <th width="10%"><?php echo e(__('Status')); ?></th>
                                        <th width="10%"><?php echo e(__('Action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->index + 1); ?></td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td><?php echo e($item->slug); ?></td>
                                            <td class="py-1">
                                                <img src="<?php echo e(asset($item->logo)); ?>" alt="image">
                                            </td>
                                            <td><?php echo e($item->status); ?></td>
                                            <td>
                                                <a href="" class="btn btn-sm btn-outline-danger"
                                                    data-toggle="tooltip" data-placement="top" title="Delete"
                                                    onclick="if(confirm('Are You Sure To Delete?')){ event.preventDefault(); getElementById('delete-form-<?php echo e($item->id); ?>').submit(); } else { event.preventDefault(); }"><i
                                                        data-feather="x-square"></i></a>
                                                <form action="<?php echo e(route('admin.brands.destroy', [$item->id])); ?>"
                                                    method="post" style="display: none;"
                                                    id="delete-form-<?php echo e($item->id); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo e(method_field('DELETE')); ?>

                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="modal fade bd-example-modal-xl" tabindex="-1" aria-labelledby="myExtraLargeModalLabel"
                            aria-hidden="true" id="create">
                            <div class="modal-dialog modal-xl">
                                <div class="modal-content">

                                    <div class="modal-header">
                                        <h5 class="modal-title h4" id="myExtraLargeModalLabel"><?php echo e(__('New Brand')); ?></h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form class="forms-sample" method="POST"
                                            action="<?php echo e(route('admin.brands.store')); ?>" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="row col-md-12 mb-3">
                                                <div class="form-group col-md-4">
                                                    <label class="form-label"><?php echo e(__('Name')); ?></label>
                                                    <input type="text" class="form-control"
                                                        placeholder="<?php echo e(__('Name')); ?>" autocomplete="off" name="name"
                                                        value="<?php echo e(old('name')); ?>" required="" id="name" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <label class="form-label"><?php echo e(__('Slug')); ?></label>
                                                    <input type="text" class="form-control"
                                                        placeholder="<?php echo e(__('Slug')); ?>" autocomplete="off" name="slug"
                                                        value="<?php echo e(old('slug')); ?>" required="" id="slug" />
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <label class="form-label"><?php echo e(__('Status')); ?></label>
                                                    <select class="form-select" data-width="100%" name="status"
                                                        id="status">
                                                        <option value=""><?php echo e(__('Status')); ?></option>
                                                        <option value="0">
                                                            Inactive</option>
                                                        <option value="1" selected>
                                                            Active</option>

                                                    </select>
                                                </div>
                                            </div>
                                            <div class="row mb-3 d-flex justify-content-center">
                                                <div class="card" style="margin-top: 28px">
                                                    <div class="card-body">
                                                        <center>
                                                            <img src="//placehold.it/100x100" id="brand-logo">
                                                            <p class="card-text mb-3" style="color: red">
                                                                <?php echo e(__('Logo Max Size 100px')); ?></p>
                                                            <input type="file" name="logo"
                                                                onchange="readPicture(this)">
                                                        </center>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-12">
                                                    <center>
                                                        <button type="reset"
                                                            class="btn btn-outline-danger"><?php echo e(__('Reset')); ?></button>
                                                        <button type="submit"
                                                            class="btn btn-outline-primary"><?php echo e(__('Save')); ?></button>
                                                    </center>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        function readPicture(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#brand-logo')
                        .attr('src', e.target.result)
                        .width(100)
                        .height(100);
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        function readPicture2(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#brand2-logo')
                        .attr('src', e.target.result)
                        .width(100)
                        .height(100);
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
        $("#name").keyup(function() {
            var name = $("#name").val();
            var slug = (name.replace(/[^a-zA-Z0-9]+/g, '-')).toLowerCase();
            $("#slug").val(slug);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\amrlogde\singlevendor\resources\views/backend/admin/brand.blade.php ENDPATH**/ ?>