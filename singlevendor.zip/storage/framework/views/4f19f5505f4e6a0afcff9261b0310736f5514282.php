
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
            <div>
                <h4 class="mb-3 mb-md-0">Welcome to Dashboard</h4>
            </div>
            
        </div>

        <div class="row">
            <div class="col-12 col-xl-12 stretch-card">
                <div class="row flex-grow-1">
                    <div class="col-md-4 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-baseline">
                                    <h6 class="card-title mb-0">Total Order</h6>
                                </div>
                                <div class="row">
                                    <div >
                                        <h3 class="m-4"><?php echo e($data['order']); ?><i data-feather="shopping-bag" class="text-success  mb-1"></i></h3>

                                    </div>
                                    <div class="col-6 col-md-12 col-xl-7">
                                        <div id="customersChart" class="mt-md-3 mt-xl-0"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-baseline">
                                    <h6 class="card-title mb-0">Completed Order</h6>
                                </div>
                                <div class="row">
                                    <div >
                                        <h3 class="m-4"><?php echo e($data['completedOrder']); ?> <i data-feather="shopping-bag" class="text-success  mb-1"></i></h3>

                                    </div>
                                    <div class="col-6 col-md-12 col-xl-7">
                                        <div id="customersChart" class="mt-md-3 mt-xl-0"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-baseline">
                                    <h6 class="card-title mb-0">Stock Product</h6>
                                </div>
                                <div class="row">
                                    <div >
                                        <h3 class="m-4"><?php echo e($data['stock']); ?> <i data-feather="shopping-bag" class="text-success  mb-1"></i></h3>

                                    </div>
                                    <div class="col-6 col-md-12 col-xl-7">
                                        <div id="customersChart" class="mt-md-3 mt-xl-0"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-baseline">
                                    <h6 class="card-title mb-0">Customers</h6>
                                </div>
                                <div class="row">
                                    <div >
                                        <h3 class="m-4"><?php echo e($data['user']); ?><i data-feather="user-check" class="text-success  mb-1"></i></h3>

                                    </div>
                                    <div class="col-6 col-md-12 col-xl-7">
                                        <div id="customersChart" class="mt-md-3 mt-xl-0"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-baseline">
                                    <h6 class="card-title mb-0">Sell Amount</h6>
                                </div>
                                <div class="row">
                                    <div >
                                        <h3 class="m-4"><?php echo e(round($data['sellAmount'])); ?> <i class="text-success  mb-1">৳</i></h3>

                                    </div>
                                    <div class="col-6 col-md-12 col-xl-7">
                                        <div id="customersChart" class="mt-md-3 mt-xl-0"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-baseline">
                                    <h6 class="card-title mb-0">Stock Amount</h6>
                                </div>
                                <div class="row">
                                    <div >
                                        <h3 class="m-4"><?php echo e(round($data['stockAmount'])); ?> <i class="text-success  mb-1">৳</i></h3>

                                    </div>
                                    <div class="col-6 col-md-12 col-xl-7">
                                        <div id="customersChart" class="mt-md-3 mt-xl-0"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- row -->

        

        

        <div class="row">
            
            <div class="col-lg-12 col-xl-12 stretch-card">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-baseline mb-2">
                            <h6 class="card-title mb-0">Today's Order</h6>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-hover mt-2">
                                <thead>
                                    <tr>
                                        <th class="pt-0">#</th>
                                        <th class="pt-0">Customer Name</th>
                                        <th class="pt-0">Payment Method</th>
                                        <th class="pt-0">Payment Status</th>
                                        <th class="pt-0">Delivered</th>
                                        <th class="pt-0">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $todaysOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e(serialNumber($todaysOrders, $loop)); ?></td>
                                            <td><?php echo e($item->user->name); ?></td>
                                            <td><?php echo e($item->paymentOption->name); ?></td>
                                            <td>
                                                <?php
                                                    switch ($item->payment_status) {
                                                        case 0:
                                                                echo '<span class="badge bg-dark text-white">Pending</span>';
                                                                break;
                                                            case 1:
                                                                echo '<span class="badge bg-success">Review</span>';
                                                                break;
                                                            case 2:
                                                                echo '<span class="badge bg-danger">Invalid</span>';
                                                                break;
                                                            case 3:
                                                                echo '<span class="badge bg-success">Completed</span>';
                                                                break;
                                                            case 4:
                                                                echo '<span class="badge bg-danger">Unpaid</span>';
                                                                break;
                                                            default:
                                                                echo 'Unknown status';

                                                    }
                                                ?>
                                            </td>
                                            <td>
                                                <span>
                                                    <?php
                                                        switch ($item->delivery_status) {
                                                            case 0:
                                                            echo 'Pending';
                                                            break;
                                                        case 1:
                                                            echo 'Confirmed';
                                                            break;
                                                        case 2:
                                                            echo 'Packed';
                                                            break;
                                                        case 3:
                                                            echo 'Shipped';
                                                            break;
                                                        case 4:
                                                            echo 'Delivered';
                                                            break;
                                                        case 5:
                                                            echo 'Cancelled';
                                                            break;
                                                        default:
                                                            echo 'Unknown status';
                                                        }
                                                    ?>
                                                </span>
                                            <td><a class="m-0 p-0" href="<?php echo e(route('admin.orders.show', $item->id)); ?>"><i
                                                        data-feather="eye"></i></a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="7" class="text-center text-danger">No Orders for today</td>
                                        </tr>
                                    <?php endif; ?>

                                </tbody>
                            </table>
                            <div class="d-flex justify-content-center">
                                <?php echo e($todaysOrders->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- row -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\amrlogde\singlevendor\resources\views/backend/admin/dashboard.blade.php ENDPATH**/ ?>