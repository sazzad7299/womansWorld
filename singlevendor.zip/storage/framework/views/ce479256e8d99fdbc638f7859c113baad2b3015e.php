<?php $__env->startSection('title', 'New Product'); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="row">
            <div class="col-md-12 grid-margin">
                <div class="card">
                    <div class="card-body">
                        <?php echo $__env->make('includes.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="d-flex justify-content-between">
                            <h6 class="card-title"><?php echo e(__('New Product')); ?></h6>
                            <a class="btn btn-outline-primary text-end"
                                href="<?php echo e(route('admin.products.index')); ?>"><?php echo e(__('All Product')); ?></a>
                        </div>
                        <form class="forms-sample" method="POST" action="<?php echo e(route('admin.products.store')); ?>"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-9">
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label class="form-label"><?php echo e(__('Name')); ?></label>
                                            <input type="text" class="form-control" placeholder="<?php echo e(__('Name')); ?>"
                                                autocomplete="off" name="name" value="<?php echo e(old('name')); ?>" required=""
                                                id="name" />
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label"><?php echo e(__('Slug')); ?></label>
                                            <input type="text" class="form-control" placeholder="<?php echo e(__('Slug')); ?>"
                                                autocomplete="off" name="slug" value="<?php echo e(old('slug')); ?>" required=""
                                                id="slug" />
                                        </div>
                                    </div>
                                    
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label class="form-label"><?php echo e(__('Category')); ?></label>
                                            <select name="category_id"  id="category_id"
                                            required="" class="js-example-basic-single form-select" data-width="100%">
                                            <option value=""> Select Category</option>
                                                <?php $__currentLoopData = $indentedCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryId => $categoryName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($categoryId); ?>" ><?php echo e(html_entity_decode($categoryName)); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label"><?php echo e(__('Brand')); ?></label>
                                            <select class="js-example-basic-single form-select" data-width="100%"
                                                name="brand_id" id="brand_id">
                                                <option value=""><?php echo e(__('Select Brand')); ?></option>
                                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>
                                        </div>
                                    </div>
                                    <div class="row mb-3">

                                        <div class="col-md-4">
                                            <label class="form-label"><?php echo e(__('Sell Price')); ?></label>
                                            <input type="text" class="form-control"
                                                placeholder="<?php echo e(__('Current Price')); ?>" autocomplete="off" name="price"
                                                value="<?php echo e(old('price')); ?>" required="" id="price" />
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label"><?php echo e(__('Purchase Price')); ?></label>
                                            <input type="text" class="form-control" placeholder="<?php echo e(__('Purchase Price')); ?>"
                                                autocomplete="off" required name="old_price" value="<?php echo e(old('old_price')); ?>"
                                                id="old_price" />
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label" for="stock"><?php echo e(__('Quantity')); ?></label>
                                            <input type="text" class="form-control" placeholder="<?php echo e(__('Quantity')); ?>"
                                                autocomplete="off" required name="stock" value="<?php echo e(old('discount')); ?>"
                                                id="stock" />
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-4">
                                            <label class="form-label"
                                                for="discount_type"><?php echo e(__('Discount Type')); ?></label>
                                            <select name="discount_type" id="discount_type" class="form-control">
                                                <option value="" selected>Discount Type</option>
                                                <option value="2">Percent</option>
                                                <option value="1">Regular</option>
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label" for="discount"><?php echo e(__('Discount')); ?></label>
                                            <input type="number" class="form-control"
                                                placeholder="<?php echo e(__('Discount')); ?>" autocomplete="off" name="discount"
                                                value="<?php echo e(old('discount')); ?>" id="discount" />
                                        </div>

                                        <div class="col-md-4">
                                            <label class="form-label"><?php echo e(__('Status')); ?></label>
                                            <select class="js-example-basic-single form-select" data-width="100%"
                                                name="status" id="status">
                                                <option value=""><?php echo e(__('Status')); ?></option>
                                                <?php $__currentLoopData = getStatus(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($status['value']); ?>" <?php echo e($status['value'] ==1 ? 'selected':''); ?>><?php echo e($status['label']); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-12">
                                            <label class="form-label"><?php echo e(__('Tags')); ?></label>
                                            <textarea class="form-control" placeholder="<?php echo e(__('Tags')); ?>" autocomplete="off" name="tags"
                                                rows="3" /><?php echo e(old('tags')); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-md-12">
                                            <label class="form-label"><?php echo e(__('Description')); ?></label>
                                            <textarea id="editor" name="description" /><?php echo e(old('description')); ?></textarea>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-3">
                                    <div class="card" style="margin-top: 28px">
                                        <div class="card-header"><?php echo e(__('Extra')); ?></div>
                                        <div class="card-body">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" value="1" name="featured">
                                                <label class="form-check-label" for="flexCheckDefault">
                                                  Featured
                                                </label>
                                              </div>
                                              <div class="form-check">
                                                <input class="form-check-input" type="checkbox" value="1" name="p_set">
                                                <label class="form-check-label" for="flexCheckChecked">
                                                  Perfume Set
                                                </label>
                                              </div>
                                              <div class="form-check">
                                                <input class="form-check-input" type="checkbox" value="1" name="new">
                                                <label class="form-check-label" for="flexCheckChecked">
                                                  New Arrival
                                                </label>
                                              </div>
                                        </div>
                                    </div>
                                    <div class="card" style="margin-top: 28px">
                                        <div class="card-header"><?php echo e(__('Display Photo')); ?></div>
                                        <div class="card-body">
                                            <center>
                                                <img src="//placehold.it/100x100" id="product-photo">
                                                <p class="card-text mb-3" style="color: red">
                                                    <?php echo e(__('Photo Max Size 100px')); ?></p>
                                                <input type="file" name="display" onchange="readPicture(this)">
                                            </center>
                                        </div>
                                    </div>
                                    <div class="card" style="margin-top: 28px">
                                        <div class="card-header"><?php echo e(__('More Photo')); ?></div>
                                        <div class="card-body">
                                            <center>
                                                <img src="//placehold.it/100x100">
                                                <p class="card-text mb-3" style="color: red">
                                                    <?php echo e(__('Photo Max Size 100px')); ?></p>
                                                <input type="file" name="photo[]" multiple="">
                                            </center>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-md-12">
                                    <center>
                                        <button type="reset"
                                            class="btn btn-outline-danger"><?php echo e(__('Reset')); ?></button>
                                        <button type="submit"
                                            class="btn btn-outline-primary"><?php echo e(__('Save')); ?></button>
                                    </center>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        function readPicture(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#product-photo')
                        .attr('src', e.target.result)
                        .width(100)
                        .height(100);
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        $(function() {
            CKEDITOR.replace('editor')
        });

        $("#name").keyup(function() {
            var name = $("#name").val();
            var slug = (name.replace(/[^a-zA-Z0-9]+/g, '-')).toLowerCase();
            $("#slug").val(slug);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\amrlogde\singlevendor\resources\views/backend/admin/products/create.blade.php ENDPATH**/ ?>