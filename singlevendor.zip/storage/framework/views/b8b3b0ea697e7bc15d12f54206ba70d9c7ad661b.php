<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title><?php echo $__env->yieldContent('title'); ?></title>
  
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <link rel="shortcut icon" href="<?php echo e(asset('public/backend/assets/images/fav.ico')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/backend/assets/plugins/core/core.css')); ?>">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <link rel="stylesheet"
      href="<?php echo e(asset('public/backend/assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.css')); ?>">
  <!-- end plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backend/assets/fonts/feather-font/css/iconfont.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/backend/assets/plugins/flag-icon-css/css/flag-icon.min.css')); ?>">
  <link href="<?php echo e(asset('public/backend/assets/plugins/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('public/backend/assets/plugins/select2/select2.min.css')); ?>" rel="stylesheet" />
  <!-- endinject -->
  <link href="<?php echo e(asset('public/backend/assets/css/app.css')); ?>" rel="stylesheet" />
  <!-- Layout styles -->
  <link rel="stylesheet" href="<?php echo e(asset('public/backend/assets/css/demo_1/style.css')); ?>">
  <?php echo $__env->yieldPushContent('css'); ?>
  <style>
    .notification{
        position: absolute;
    z-index: 99999;
    color: white;
    top: -3px;
    right: 0;
    background: #cc1616;
    padding: 2px 8px;
    border-radius: 10px;
    }
  </style>
</head>
<body>
    <script src="<?php echo e(asset('public/backend/assets/js/spinner.js')); ?>"></script>

    <div class="main-wrapper" id="app">
        <nav class="sidebar">
            <div class="sidebar-header">
                <a href="<?php echo e(URL::to('/')); ?>" class="sidebar-brand" style="font-size: 20px;line-height:18px">
                    PERFUME <br><span>SOMAHAR</span>
                </a>
                <div class="sidebar-toggler not-active">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
            <?php echo $__env->make('backend.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>
        <nav class="settings-sidebar">
            <div class="sidebar-body">
              <a href="#" class="settings-sidebar-toggler">
                <i data-feather="settings"></i>
              </a>
              <h6 class="text-muted">Sidebar:</h6>
              <div class="form-group border-bottom">
                <div class="form-check form-check-inline">
                  <label class="form-check-label">
                    <input type="radio" class="form-check-input" name="sidebarThemeSettings" id="sidebarLight" value="sidebar-light" checked>
                    Light
                  </label>
                </div>
                <div class="form-check form-check-inline">
                  <label class="form-check-label">
                    <input type="radio" class="form-check-input" name="sidebarThemeSettings" id="sidebarDark" value="sidebar-dark">
                    Dark
                  </label>
                </div>
              </div>
              
            </div>
        </nav>
        <div class="page-wrapper">

            <?php echo $__env->make('backend.layouts.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php $__env->startSection('content'); ?>

            <?php echo $__env->yieldSection(); ?>
            <footer
                class="footer d-flex flex-column flex-md-row align-items-center justify-content-between px-4 py-3 border-top small">
                <p class="text-muted mb-1 mb-md-0"><?php echo e(__('Copyright ©')); ?> <?php echo e(date('Y')); ?> <a
                        href="https://www.ictbanglabd.com/" target="_blank"><?php echo e(__('ictbd')); ?></a>.</p>
                <p class="text-muted">Handcrafted With <i class="mb-1 text-primary ms-1 icon-sm"
                        data-feather="heart"></i></p>
            </footer>
        </div>
    </div>
    <script src="<?php echo e(asset('public/backend/assets/plugins/core/core.js')); ?>"></script>
    <!-- endinject -->
    <!-- plugin js for this page -->
    <script src="<?php echo e(asset('public/backend/assets/plugins/chartjs/chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/backend/assets/plugins/jquery.flot/jquery.flot.js')); ?>"></script>
    <script src="<?php echo e(asset('public/backend/assets/plugins/jquery.flot/jquery.flot.resize.js')); ?>"></script>
    <script src="<?php echo e(asset('public/backend/assets/plugins/bootstrap-datepicker/bootstrap-datepicker.min.js')); ?>"></script>
    <!-- end plugin js for this page -->
    <!-- inject:js -->
    <script src="<?php echo e(asset('public/backend/assets/plugins/feather-icons/feather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/backend/assets/plugins/progressbar-js/progressbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/backend/assets/plugins/sweetalert2/sweetalert2.min.js')); ?>"></script>

    <script src="<?php echo e(asset('public/backend/assets/plugins/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/backend/assets/js/template.js')); ?>"></script>
    <!-- endinject -->
    <!-- custom js for this page -->
    <script src="<?php echo e(asset('public/backend/assets/js/dashboard.js')); ?>"></script>
    <script src="<?php echo e(asset('public/backend/assets/js/datepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('public/backend/assets/js/data-table.js')); ?>"></script>
    <script src="<?php echo e(asset('public/backend/assets/js/select2.js')); ?>"></script>
    <script src="https://cdn.ckeditor.com/4.5.7/full/ckeditor.js"></script>
    <script>
        const Toast = Swal.mixin({
            toast: true,
            position: 'center',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
        });

        <?php if(session()->has('success') || session()->has('error')): ?>
            <?php if(session()->has('error')): ?>
                Toast.fire({
                    icon: 'error',
                    title: '<?php echo e(session('error')); ?>'
                })
            <?php else: ?>
                Toast.fire({
                    icon: 'success',
                    title: '<?php echo e(session('success')); ?>'
                })
            <?php endif; ?>
        <?php endif; ?>
    </script>

    <?php $__env->startSection('footer'); ?>

    <?php echo $__env->yieldSection(); ?>
    <?php echo $__env->yieldPushContent('js'); ?>

</body>

</html>
<?php /**PATH E:\wamp64\www\amrlogde\singlevendor\resources\views/backend/layouts/app.blade.php ENDPATH**/ ?>