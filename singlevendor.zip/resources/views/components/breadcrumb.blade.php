 <!-- Breadcrumb Area -->
 <div class="tm-breadcrumb-area tm-padding-section bg-grey" data-bgimage="{{asset('public/frontend/assets/images/breadcrumb-bg.jpg')}}">
    <div class="container">
        <div class="tm-breadcrumb">
            <h2>Page title</h2>
            <ul>
                <li><a href="{{ url('/')}}l">Home</a></li>
                <li>Page</li>
            </ul>
        </div>
    </div>
</div>
<!--// Breadcrumb Area -->
